$(function() {
    var width = $('.main__slider-box').width();
        interval = 15000;

    $('.slider__slide:last').clone().prependTo('.slider-box__slider');
    $('.slider__slide').eq(1).clone().appendTo('.slider-box__slider');
    $('.slider-box__slider').css('margin-left', -width);
    setInterval('animation()', interval);
});

    function animation () {
        var margin = parseInt($('.slider-box__slider').css('marginLeft'));
            width = $('.main__slider-box').width();
            slidersAmount=$('.slider-box__slider').children().length;
        if(margin!=(-width*(slidersAmount-1)))
        {
            margin=margin-width;
        }else{
            $('.slider-box__slider').css('margin-left', -width);
            margin=-width*2;
        }
        $('.slider-box__slider').animate({marginLeft:margin},5000);
    };
